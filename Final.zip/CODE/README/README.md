# Harambe_Lives
CSE 6242 Data &amp; Visual Analytics Final Project - Fake News Detection


## Project Goal
This project uses Flask on the backend to host webpages and enable python script execution upon events observed on the webpage. For example, when the user types a URL into the input bar and hits enter, a script runs to scrape the text content of the entered URL. 


## Project Components
 

## Methodology
 

## Setup
 

#### Install newspaper python package
http://newspaper.readthedocs.io/en/latest/


#### Install Flask
pip install Flask 

## Execution
python run.py
open web browser, go to 127.0.0.1/5000
